from django.apps import AppConfig


class ManytomanyConfig(AppConfig):
    name = 'manytomany'
