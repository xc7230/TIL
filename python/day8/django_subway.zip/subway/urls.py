from django.urls import path
from . import views

app_name ="subway"
urlpatterns = [
    #{% url 'app_name:설정name'%}
    path('', views.index, name='index'),
    path('new_order/', views.new_order, name = 'new_order'),
    path('create/', views.create, name= 'create'),
    #{% url '설정name' 넘김id %}
    path('detail/<int:id>/', views.detail, name='detail'),
    path('edit/<int:id>/', views.edit, name = 'edit'),
    path('update/<int:id>/', views.update, name = 'update'),
    path('delete/<int:id>/', views.delete, name = 'delete'),

]