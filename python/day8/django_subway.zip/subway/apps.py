from django.apps import AppConfig


class SubwayConfig(AppConfig):
    name = 'subway'
